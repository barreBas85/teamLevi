function backgroundColorBlack(){
	document.body.style.backgroundColor = 'black';
}

function backgroundColorRed(){
	document.body.style.backgroundColor = 'red';
}

function backgroundColorOrange(){
	document.body.style.backgroundColor = 'orange';
}

function backgroundColorWhite(){
	document.body.style.backgroundColor = 'white';
}

function sound(){
	var audio = new Audio('ep.mp3');
	audio.play();
	return audio;
}

window.onscroll = function() {stickyNav()};
        
const navbar = document.getElementById("navbar");
const sticky = navbar.offsetTop;
        
function stickyNav() {
    if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky")
    } else {
        navbar.classList.remove("sticky");
    }
} // sticky navbar